#!/usr/bin/env bash
# Oppdaterer en eksisterende installasjon med ny kode. Trenger IKKE internett.
# Logger, katalog, AI-instrukser og revisjonslogg beholdes.
# Kjør fra mappen med de nye filene:   sudo bash update.sh
set -euo pipefail
APP_DIR="/opt/nvidia-sysadmin"
SRC_DIR="$(cd "$(dirname "$0")" && pwd)"
if [ "$EUID" -ne 0 ]; then echo "Kjør med sudo: sudo bash update.sh"; exit 1; fi
if [ ! -d "$APP_DIR" ]; then echo "Fant ikke $APP_DIR. Kjør install.sh først."; exit 1; fi

echo "==> Kopierer ny kode og nettsider"
cp "$SRC_DIR/app.py" "$SRC_DIR/requirements.txt" "$SRC_DIR/set_password.sh" "$APP_DIR/"
mkdir -p "$APP_DIR/static" && cp -r "$SRC_DIR/static/." "$APP_DIR/static/"
chown -R sysadminbot:sysadminbot "$APP_DIR"

if [ ! -f "$APP_DIR/admin_password" ]; then
  echo "==> Det er ikke satt et admin-passord ennå"
  bash "$APP_DIR/set_password.sh"
fi

echo "==> Starter tjenesten på nytt"
systemctl restart nvidia-sysadmin
sleep 2
systemctl is-active --quiet nvidia-sysadmin && echo "OK: tjenesten kjører." || { echo "Tjenesten startet ikke. Se: journalctl -u nvidia-sysadmin -n 30"; exit 1; }

IP=$(hostname -I | awk '{print $1}')
echo
echo "Ferdig!  SOC-siden:  http://$IP"
echo "         Admin:      http://$IP/admin"
