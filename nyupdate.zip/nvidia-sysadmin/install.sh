#!/usr/bin/env bash
# Installerer NVIDIA AI-systemadministrator på Ubuntu Server.
# Kjør fra mappen nvidia-sysadmin:   sudo bash install.sh
set -euo pipefail

MODEL="${MODEL:-qwen2.5:7b}"
PORT="${PORT:-80}"
APP_DIR="/opt/nvidia-sysadmin"
SRC_DIR="$(cd "$(dirname "$0")" && pwd)"

if [ "$EUID" -ne 0 ]; then echo "Kjør med sudo: sudo bash install.sh"; exit 1; fi

echo "==> 1/5 Installerer systempakker"
apt-get update -y
apt-get install -y python3 python3-venv python3-pip curl

echo "==> 2/5 Installerer Ollama"
if ! command -v ollama >/dev/null; then
  curl -fsSL https://ollama.com/install.sh | sh
fi
systemctl enable --now ollama
sleep 3

echo "==> 3/5 Laster ned språkmodellen $MODEL (kan ta flere minutter)"
ollama pull "$MODEL"

echo "==> 4/5 Kopierer appen til $APP_DIR"
id -u sysadminbot >/dev/null 2>&1 || useradd --system --home "$APP_DIR" --shell /usr/sbin/nologin sysadminbot
mkdir -p "$APP_DIR"
if [ "$SRC_DIR" != "$APP_DIR" ]; then
  # Overskriv kode og nettside, men behold eksisterende logger, prompt og revisjonslogg.
  cp "$SRC_DIR/app.py" "$SRC_DIR/requirements.txt" "$SRC_DIR/set_password.sh" "$APP_DIR/"
  mkdir -p "$APP_DIR/static" && cp -r "$SRC_DIR/static/." "$APP_DIR/static/"
  [ -f "$APP_DIR/system_prompt.txt" ] || cp "$SRC_DIR/system_prompt.txt" "$APP_DIR/"
  [ -d "$APP_DIR/logs" ] || cp -r "$SRC_DIR/logs" "$APP_DIR/"
fi
python3 -m venv "$APP_DIR/venv"
"$APP_DIR/venv/bin/pip" install -q -r "$APP_DIR/requirements.txt"
chown -R sysadminbot:sysadminbot "$APP_DIR"
[ -f "$APP_DIR/admin_password" ] || bash "$APP_DIR/set_password.sh"

echo "==> 5/5 Oppretter tjenesten nvidia-sysadmin"
cat > /etc/systemd/system/nvidia-sysadmin.service <<EOF
[Unit]
Description=NVIDIA AI-systemadministrator
After=network-online.target ollama.service
Wants=ollama.service

[Service]
User=sysadminbot
WorkingDirectory=$APP_DIR
Environment=MODEL=$MODEL
Environment=OLLAMA_URL=http://127.0.0.1:11434
ExecStart=$APP_DIR/venv/bin/uvicorn app:app --host 0.0.0.0 --port $PORT
AmbientCapabilities=CAP_NET_BIND_SERVICE
Restart=always

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable --now nvidia-sysadmin
systemctl restart nvidia-sysadmin

IP=$(hostname -I | awk '{print $1}')
echo
echo "Ferdig! Åpne http://$IP$( [ "$PORT" = 80 ] || echo ":$PORT" ) fra en analyseklient."
echo "Admin-panel:          http://$IP$( [ "$PORT" = 80 ] || echo ":$PORT" )/admin"
echo "Logger legges i:     $APP_DIR/logs/  (og registreres i catalog.json)"
echo "AI-ens instrukser:    $APP_DIR/system_prompt.txt"
echo "Revisjonslogg:        $APP_DIR/audit.jsonl"
