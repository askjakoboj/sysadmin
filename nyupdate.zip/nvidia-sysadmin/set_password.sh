#!/usr/bin/env bash
# Setter (eller bytter) admin-passordet for /admin.   sudo bash set_password.sh
set -euo pipefail
APP_DIR="/opt/nvidia-sysadmin"
if [ "$EUID" -ne 0 ]; then echo "Kjør med sudo: sudo bash set_password.sh"; exit 1; fi

while true; do
  read -r -s -p "Velg admin-passord (minst 8 tegn): " P1; echo
  read -r -s -p "Skriv det en gang til: " P2; echo
  if [ "$P1" != "$P2" ]; then echo "Passordene er ikke like. Prøv igjen."; continue; fi
  if [ "${#P1}" -lt 8 ]; then echo "For kort. Prøv igjen."; continue; fi
  break
done

ADMIN_PW="$P1" python3 -c 'import os,hashlib;p=os.environ["ADMIN_PW"].encode();s=os.urandom(16);print(s.hex()+"$"+hashlib.pbkdf2_hmac("sha256",p,s,200000).hex())' > "$APP_DIR/admin_password"
chown sysadminbot:sysadminbot "$APP_DIR/admin_password"
chmod 600 "$APP_DIR/admin_password"
echo "Admin-passord er satt."
