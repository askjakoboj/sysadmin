"""
NVIDIA IT - AI-systemadministrator
En liten webapp der SOC-analytikere ber om logger. AI-en vurderer anmodningen,
og hvis den godkjenner, leverer appen den ORIGINALE filen fra logs/-mappen.
AI-en ser aldri innholdet i loggene, bare katalogen (logs/catalog.json).
"""
import asyncio
import datetime
import hashlib
import json
import os
import random
import re
import secrets
import time
from pathlib import Path

import httpx
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

BASE = Path(__file__).resolve().parent
LOG_DIR = BASE / "logs"
CATALOG_FILE = LOG_DIR / "catalog.json"
PROMPT_FILE = BASE / "system_prompt.txt"
AUDIT_FILE = BASE / "audit.jsonl"
ADMIN_FILE = BASE / "admin_password"   # salt$pbkdf2-hash, lages av set_password.sh
SESSION_HOURS = 8
SAFE_NAME = re.compile(r"^[A-Za-z0-9._-]{1,120}$")

OLLAMA_URL = os.getenv("OLLAMA_URL", "http://127.0.0.1:11434")
MODEL = os.getenv("MODEL", "qwen2.5:7b")
MAX_TOOL_ROUNDS = 3

app = FastAPI(title="NVIDIA IT - Systemadministrator")
downloads: dict[str, str] = {}  # token -> filnavn

TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "gi_ut_logg",
            "description": (
                "Gir analytikeren tilgang til en loggfil fra katalogen. "
                "Kall KUN denne når anmodningen er godkjent etter reglene dine."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "fil": {"type": "string", "description": "Eksakt filnavn fra katalogen"},
                    "begrunnelse": {"type": "string", "description": "Kort begrunnelse for at anmodningen godkjennes"},
                },
                "required": ["fil", "begrunnelse"],
            },
        },
    }
]


def now() -> str:
    return datetime.datetime.now().isoformat(timespec="seconds")


def audit(entry: dict) -> None:
    entry = {"tid": now(), **entry}
    with AUDIT_FILE.open("a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")


def load_catalog() -> list[dict]:
    # Leses på nytt ved hver forespørsel, så du kan endre katalogen uten omstart.
    return json.loads(CATALOG_FILE.read_text(encoding="utf-8"))


def build_system_prompt(catalog: list[dict], analyst: str) -> str:
    lines = []
    for e in catalog:
        lines.append(
            f"- fil: {e['file']} | maskin: {e.get('host', '?')} | innhold: {e.get('description', '')} "
            f"| regler for utlevering: {e.get('rules', 'Ingen spesielle krav utover de generelle reglene.')}"
        )
    prompt = PROMPT_FILE.read_text(encoding="utf-8")
    if "{{KATALOG}}" not in prompt:
        # Sikkerhetsnett: AI-en må alltid kjenne katalogen, selv om plassholderen er slettet.
        prompt += "\n\nLOGGKATALOG (dette er ALT du kan gi ut)\n{{KATALOG}}"
    prompt = prompt.replace("{{KATALOG}}", "\n".join(lines))
    prompt = prompt.replace("{{ANALYTIKER}}", analyst)
    prompt = prompt.replace("{{DATO}}", datetime.date.today().isoformat())
    prompt += (
        "\n\nTEKNISK: Når du gir ut en logg, bruk verktøyet gi_ut_logg via function calling. "
        "Skriv aldri verktøykallet, JSON eller filnavn-kode som tekst i svaret ditt."
    )
    return prompt


# Små modeller skriver noen ganger verktøykallet som tekst, f.eks.
#   Gi ut_logg {"fil": "DC_security_events.csv", "begrunnelse": "..."}
# Disse fanges opp og behandles som et ekte verktøykall.
TEXT_CALL_MARKER = re.compile(r"gi[\s_]*ut[\s_]*logg|<tool_call>|\"name\"\s*:\s*\"gi_ut_logg\"", re.I)
TEXT_CALL_JSON = re.compile(r"\{[^{}]*\"fil\"\s*:\s*\"([^\"]+)\"[^{}]*\}", re.S)
TEXT_CALL_REASON = re.compile(r"\"begrunnelse\"\s*:\s*\"([^\"]*)\"")


def parse_text_tool_call(content: str, files: dict, history: list[dict]) -> dict | None:
    if not content or not TEXT_CALL_MARKER.search(content):
        return None
    m = TEXT_CALL_JSON.search(content)
    if not m or m.group(1).strip() not in files:
        return None
    # Ikke la en analytiker lure modellen til å "gjenta" et verktøykall de selv har skrevet.
    if any(h["role"] == "user" and '"fil"' in h["content"] for h in history):
        return None
    reason = TEXT_CALL_REASON.search(m.group(0))
    return {"function": {"name": "gi_ut_logg",
                         "arguments": {"fil": m.group(1).strip(), "begrunnelse": reason.group(1) if reason else ""}}}


def strip_text_tool_call(content: str) -> str:
    if not TEXT_CALL_MARKER.search(content or ""):
        return content
    content = re.sub(r"<tool_call>.*?</tool_call>", "", content, flags=re.S)
    content = TEXT_CALL_JSON.sub("", content)
    content = re.sub(r"\bgi[\s_]*ut[\s_]*logg\b:?", "", content, flags=re.I)
    return content.strip()


def safe_path(filename: str) -> Path | None:
    p = (LOG_DIR / filename).resolve()
    if p.parent != LOG_DIR or not p.is_file() or p.name == "catalog.json":
        return None
    return p


# ----------------------------------------------------------------------------
# TILGJENGELIGHET (simulert travel systemadministrator)
# ----------------------------------------------------------------------------
SETTINGS_FILE = BASE / "settings.json"
DEFAULT_SETTINGS = {
    "status_mode": "auto",      # auto | available | busy
    "busy_percent": 50,         # auto: hvor stor andel av tiden SYSADMIN er opptatt
    "block_minutes": 10,        # auto: hvor ofte status kan bytte
    "available_min": 5,         # ventetid (sek) før SYSADMIN ser på saken når tilgjengelig
    "available_max": 20,
    "busy_min": 60,             # ventetid (sek) når opptatt
    "busy_max": 120,
}


def load_settings() -> dict:
    s = dict(DEFAULT_SETTINGS)
    try:
        s.update(json.loads(SETTINGS_FILE.read_text(encoding="utf-8")))
    except Exception:
        pass
    return s


def current_state(s: dict | None = None) -> str:
    s = s or load_settings()
    if s["status_mode"] in ("available", "busy"):
        return s["status_mode"]
    block = int(time.time() // (max(1, int(s["block_minutes"])) * 60))
    return "busy" if random.Random(block * 7919).random() * 100 < float(s["busy_percent"]) else "available"


def pick_delay(state: str, s: dict) -> float:
    lo, hi = (s["busy_min"], s["busy_max"]) if state == "busy" else (s["available_min"], s["available_max"])
    lo, hi = max(0, float(lo)), max(0, float(hi))
    return random.uniform(min(lo, hi), max(lo, hi))


# ----------------------------------------------------------------------------
# SAKSKØ: forespørsler behandles i bakgrunnen, nettleseren spør etter status
# ----------------------------------------------------------------------------
jobs: dict[str, dict] = {}  # id -> {status, analyst, created, result/error}


def cleanup_jobs() -> None:
    cutoff = time.time() - 3600
    for jid in [j for j, v in jobs.items() if v["created"] < cutoff]:
        jobs.pop(jid, None)


class ChatRequest(BaseModel):
    analyst: str
    messages: list[dict]


async def ask_model(analyst: str, ip: str, history: list[dict]) -> dict:
    catalog = load_catalog()
    files = {e["file"]: e for e in catalog}
    msgs = [{"role": "system", "content": build_system_prompt(catalog, analyst)}] + history
    released = []
    msg: dict = {}

    async with httpx.AsyncClient(timeout=600) as client:
        for _ in range(MAX_TOOL_ROUNDS + 1):
            try:
                r = await client.post(
                    f"{OLLAMA_URL}/api/chat",
                    json={"model": MODEL, "messages": msgs, "tools": TOOLS, "stream": False,
                          "options": {"temperature": 0.3}},
                )
            except httpx.HTTPError as e:
                raise RuntimeError(f"Får ikke kontakt med språkmodellen: {e}")
            if r.status_code != 200:
                raise RuntimeError(f"Språkmodellen svarte med feil: {r.text[:300]}")

            msg = r.json().get("message", {})
            calls = msg.get("tool_calls") or []
            if not calls:
                text_call = parse_text_tool_call(msg.get("content", ""), files, history)
                if text_call and not any(x["file"] == text_call["function"]["arguments"]["fil"] for x in released):
                    calls = [text_call]
                    msg = {"role": "assistant", "content": "", "tool_calls": calls}
            if not calls:
                break

            msgs.append(msg)
            for call in calls:
                fn = call.get("function", {})
                args = fn.get("arguments") or {}
                if isinstance(args, str):
                    try:
                        args = json.loads(args)
                    except json.JSONDecodeError:
                        args = {}

                if fn.get("name") != "gi_ut_logg":
                    result = "Feil: ukjent verktøy."
                else:
                    fil = str(args.get("fil", "")).strip()
                    path = safe_path(fil) if fil in files else None
                    if not path:
                        result = f"Feil: filen '{fil}' finnes ikke i katalogen. Ingenting ble gitt ut."
                    elif any(x["file"] == fil for x in released):
                        result = f"{fil} er allerede gitt ut i dette svaret."
                    else:
                        token = secrets.token_urlsafe(16)
                        downloads[token] = fil
                        released.append({"file": fil, "host": files[fil].get("host", ""), "url": f"/download/{token}"})
                        audit({"type": "utlevert", "analytiker": analyst, "ip": ip, "fil": fil,
                               "begrunnelse": args.get("begrunnelse", "")})
                        result = (
                            f"OK: {fil} er gitt ut til {analyst}. Brukeren får nedlastingslenken automatisk. "
                            "Ikke skriv lenke eller innhold selv, bare bekreft kort."
                        )
                msgs.append({"role": "tool", "content": result, "tool_name": fn.get("name", "")})

    reply = strip_text_tool_call((msg.get("content") or "").strip())
    if not reply:
        reply = "Anmodningen er behandlet." if released else "Jeg har ikke noe svar på det. Kan du omformulere anmodningen?"
    audit({"type": "svar", "analytiker": analyst, "ip": ip, "tekst": reply,
           "utlevert": [x["file"] for x in released]})
    return {"reply": reply, "released": released}


async def run_job(jid: str, analyst: str, ip: str, history: list[dict], delay: float) -> None:
    job = jobs[jid]
    try:
        await asyncio.sleep(delay)
        job["status"] = "processing"
        job["result"] = await ask_model(analyst, ip, history)
        job["status"] = "done"
    except Exception as e:
        job["status"] = "error"
        job["error"] = str(e)


@app.post("/api/chat")
async def chat(req: ChatRequest, request: Request):
    analyst = (req.analyst or "").strip()[:60] or "ukjent"
    ip = request.client.host if request.client else "?"
    cleanup_jobs()

    if any(j["analyst"] == analyst and j["status"] in ("queued", "processing") for j in jobs.values()):
        raise HTTPException(409, "Du har allerede en forespørsel som venter på behandling.")

    # Bare bruker/assistent-meldinger fra nettleseren slippes inn (ingen falske systemmeldinger).
    history = [
        {"role": m["role"], "content": str(m.get("content", ""))[:4000]}
        for m in req.messages[-20:]
        if m.get("role") in ("user", "assistant")
    ]
    if not history or history[-1]["role"] != "user":
        raise HTTPException(400, "Siste melding må være fra brukeren.")

    s = load_settings()
    state = current_state(s)
    delay = pick_delay(state, s)
    audit({"type": "melding", "analytiker": analyst, "ip": ip, "tekst": history[-1]["content"],
           "status": state, "ventetid_sek": round(delay)})

    jid = secrets.token_urlsafe(12)
    jobs[jid] = {"status": "queued", "analyst": analyst, "created": time.time()}
    # Referansen lagres så oppgaven ikke ryddes bort av Python før den er ferdig.
    jobs[jid]["task"] = asyncio.create_task(run_job(jid, analyst, ip, history, delay))
    return {"job": jid, "state": state}


@app.get("/api/job/{jid}")
async def job_status(jid: str):
    job = jobs.get(jid)
    if not job:
        raise HTTPException(404, "Ukjent sak.")
    out = {"status": job["status"]}
    if job["status"] == "done":
        out.update(job["result"])
    elif job["status"] == "error":
        out["error"] = job.get("error", "Ukjent feil")
    return out


@app.get("/download/{token}")
async def download(token: str):
    fil = downloads.get(token)
    path = safe_path(fil) if fil else None
    if not path:
        raise HTTPException(404, "Ukjent eller utløpt lenke.")
    return FileResponse(path, filename=path.name)


@app.get("/api/status")
async def status():
    try:
        async with httpx.AsyncClient(timeout=3) as client:
            r = await client.get(f"{OLLAMA_URL}/api/tags")
            models = [m["name"] for m in r.json().get("models", [])]
        ok = any(m == MODEL or m.startswith(MODEL + ":") for m in models)
    except Exception:
        ok = False
    return {"online": ok, "model": MODEL, "state": current_state()}


# ----------------------------------------------------------------------------
# ADMIN
# ----------------------------------------------------------------------------
sessions: dict[str, float] = {}  # token -> utløpstid


def check_password(pw: str) -> bool:
    try:
        salt, stored = ADMIN_FILE.read_text().strip().split("$")
    except Exception:
        return False
    calc = hashlib.pbkdf2_hmac("sha256", pw.encode(), bytes.fromhex(salt), 200_000).hex()
    return secrets.compare_digest(calc, stored)


def require_admin(request: Request) -> None:
    exp = sessions.get(request.cookies.get("admin_session") or "")
    if not exp or exp < time.time():
        raise HTTPException(401, "Ikke innlogget")


def save_catalog(catalog: list[dict]) -> None:
    tmp = CATALOG_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(catalog, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(CATALOG_FILE)


def valid_name(name: str) -> str:
    if not SAFE_NAME.match(name) or name.startswith(".") or name in ("catalog.json", "catalog.tmp"):
        raise HTTPException(400, "Ugyldig filnavn. Bruk bare bokstaver, tall, punktum, bindestrek og understrek.")
    return name


class LoginRequest(BaseModel):
    password: str


class EntryUpdate(BaseModel):
    host: str = ""
    description: str = ""
    rules: str = ""


class PromptUpdate(BaseModel):
    text: str


@app.get("/admin")
async def admin_page():
    return FileResponse(BASE / "static" / "admin.html")


@app.post("/admin/api/login")
async def admin_login(body: LoginRequest, request: Request):
    ip = request.client.host if request.client else "?"
    if not ADMIN_FILE.exists():
        raise HTTPException(503, "Admin-passord er ikke satt. Kjør: sudo bash set_password.sh")
    if not check_password(body.password):
        audit({"type": "admin_innlogging_feilet", "ip": ip})
        await asyncio.sleep(1)
        raise HTTPException(401, "Feil passord")
    token = secrets.token_urlsafe(32)
    sessions[token] = time.time() + SESSION_HOURS * 3600
    audit({"type": "admin_innlogget", "ip": ip})
    resp = JSONResponse({"ok": True})
    resp.set_cookie("admin_session", token, httponly=True, samesite="strict", max_age=SESSION_HOURS * 3600)
    return resp


@app.post("/admin/api/logout")
async def admin_logout(request: Request):
    sessions.pop(request.cookies.get("admin_session") or "", None)
    resp = JSONResponse({"ok": True})
    resp.delete_cookie("admin_session")
    return resp


@app.get("/admin/api/files")
async def admin_files(request: Request):
    require_admin(request)
    counts: dict[str, int] = {}
    if AUDIT_FILE.exists():
        for line in AUDIT_FILE.read_text(encoding="utf-8").splitlines():
            try:
                e = json.loads(line)
            except json.JSONDecodeError:
                continue
            if e.get("type") == "utlevert":
                counts[e.get("fil", "")] = counts.get(e.get("fil", ""), 0) + 1
    catalog = load_catalog()
    listed = {e["file"] for e in catalog}
    out = []
    for e in catalog:
        p = LOG_DIR / e["file"]
        out.append({**e, "exists": p.is_file(), "size": p.stat().st_size if p.is_file() else 0,
                    "released": counts.get(e["file"], 0)})
    unlisted = sorted(p.name for p in LOG_DIR.iterdir()
                      if p.is_file() and p.name not in listed and p.name not in ("catalog.json", "catalog.tmp"))
    return {"files": out, "unlisted": unlisted}


@app.put("/admin/api/files/{name}")
async def admin_upload(name: str, request: Request, host: str = "", description: str = "", rules: str = ""):
    """Laster opp (eller erstatter) en fil. Innholdet sendes som rå body."""
    require_admin(request)
    name = valid_name(name)
    tmp = LOG_DIR / f".upload-{secrets.token_hex(6)}"
    size = 0
    with tmp.open("wb") as f:
        async for chunk in request.stream():
            size += len(chunk)
            f.write(chunk)
    tmp.replace(LOG_DIR / name)

    catalog = load_catalog()
    entry = next((e for e in catalog if e["file"] == name), None)
    if entry is None:
        catalog.append({"file": name, "host": host, "description": description, "rules": rules})
    elif host or description or rules:
        entry.update({"host": host, "description": description, "rules": rules})
    save_catalog(catalog)
    audit({"type": "admin_lastet_opp", "fil": name, "bytes": size})
    return {"ok": True, "size": size}


@app.put("/admin/api/catalog/{name}")
async def admin_update_entry(name: str, body: EntryUpdate, request: Request):
    require_admin(request)
    name = valid_name(name)
    catalog = load_catalog()
    entry = next((e for e in catalog if e["file"] == name), None)
    if entry is None:
        if not (LOG_DIR / name).is_file():
            raise HTTPException(404, "Filen finnes ikke")
        entry = {"file": name}
        catalog.append(entry)
    entry.update(body.model_dump())
    save_catalog(catalog)
    audit({"type": "admin_endret_katalog", "fil": name})
    return {"ok": True}


@app.delete("/admin/api/files/{name}")
async def admin_delete(name: str, request: Request):
    require_admin(request)
    name = valid_name(name)
    catalog = [e for e in load_catalog() if e["file"] != name]
    save_catalog(catalog)
    (LOG_DIR / name).unlink(missing_ok=True)
    for t in [t for t, f in downloads.items() if f == name]:
        downloads.pop(t, None)
    audit({"type": "admin_slettet", "fil": name})
    return {"ok": True}


@app.get("/admin/api/prompt")
async def admin_get_prompt(request: Request):
    require_admin(request)
    return {"text": PROMPT_FILE.read_text(encoding="utf-8")}


@app.put("/admin/api/prompt")
async def admin_set_prompt(body: PromptUpdate, request: Request):
    require_admin(request)
    if not body.text.strip():
        raise HTTPException(400, "Instruksene kan ikke være tomme.")
    backup = PROMPT_FILE.with_suffix(".bak")
    backup.write_text(PROMPT_FILE.read_text(encoding="utf-8"), encoding="utf-8")
    PROMPT_FILE.write_text(body.text, encoding="utf-8")
    audit({"type": "admin_endret_instrukser"})
    return {"ok": True}


@app.get("/admin/api/audit")
async def admin_audit(request: Request, limit: int = 300):
    require_admin(request)
    if not AUDIT_FILE.exists():
        return {"entries": []}
    lines = AUDIT_FILE.read_text(encoding="utf-8").splitlines()[-limit:]
    entries = []
    for line in reversed(lines):
        try:
            entries.append(json.loads(line))
        except json.JSONDecodeError:
            pass
    return {"entries": entries}


class SettingsUpdate(BaseModel):
    status_mode: str
    busy_percent: float
    block_minutes: int
    available_min: float
    available_max: float
    busy_min: float
    busy_max: float


@app.get("/admin/api/settings")
async def admin_get_settings(request: Request):
    require_admin(request)
    s = load_settings()
    queued = sum(1 for j in jobs.values() if j["status"] in ("queued", "processing"))
    return {"settings": s, "state": current_state(s), "queue": queued}


@app.put("/admin/api/settings")
async def admin_set_settings(body: SettingsUpdate, request: Request):
    require_admin(request)
    data = body.model_dump()
    if data["status_mode"] not in ("auto", "available", "busy"):
        raise HTTPException(400, "Ugyldig status.")
    for k in ("available_min", "available_max", "busy_min", "busy_max"):
        if not 0 <= data[k] <= 1800:
            raise HTTPException(400, "Ventetider må være mellom 0 og 1800 sekunder.")
    data["busy_percent"] = min(100, max(0, data["busy_percent"]))
    data["block_minutes"] = min(240, max(1, data["block_minutes"]))
    SETTINGS_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")
    audit({"type": "admin_endret_innstillinger"})
    return {"ok": True, "state": current_state(data)}


app.mount("/", StaticFiles(directory=BASE / "static", html=True), name="static")
