"""
NVIDIA IT - AI-systemadministrator
En liten webapp der SOC-analytikere ber om logger. AI-en vurderer anmodningen,
og hvis den godkjenner, leverer appen den ORIGINALE filen fra logs/-mappen.
AI-en ser aldri innholdet i loggene, bare katalogen (logs/catalog.json).
"""
import datetime
import json
import os
import secrets
from pathlib import Path

import httpx
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

BASE = Path(__file__).resolve().parent
LOG_DIR = BASE / "logs"
CATALOG_FILE = LOG_DIR / "catalog.json"
PROMPT_FILE = BASE / "system_prompt.txt"
AUDIT_FILE = BASE / "audit.jsonl"

OLLAMA_URL = os.getenv("OLLAMA_URL", "http://127.0.0.1:11434")
MODEL = os.getenv("MODEL", "qwen2.5:7b")
MAX_TOOL_ROUNDS = 3

app = FastAPI(title="NVIDIA IT - Systemadministrator")
downloads: dict[str, str] = {}  # token -> filnavn

TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "gi_ut_logg",
            "description": (
                "Gir analytikeren tilgang til en loggfil fra katalogen. "
                "Kall KUN denne når anmodningen er godkjent etter reglene dine."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "fil": {"type": "string", "description": "Eksakt filnavn fra katalogen"},
                    "begrunnelse": {"type": "string", "description": "Kort begrunnelse for at anmodningen godkjennes"},
                },
                "required": ["fil", "begrunnelse"],
            },
        },
    }
]


def now() -> str:
    return datetime.datetime.now().isoformat(timespec="seconds")


def audit(entry: dict) -> None:
    entry = {"tid": now(), **entry}
    with AUDIT_FILE.open("a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")


def load_catalog() -> list[dict]:
    # Leses på nytt ved hver forespørsel, så du kan endre katalogen uten omstart.
    return json.loads(CATALOG_FILE.read_text(encoding="utf-8"))


def build_system_prompt(catalog: list[dict], analyst: str) -> str:
    lines = []
    for e in catalog:
        lines.append(
            f"- fil: {e['file']} | maskin: {e.get('host', '?')} | innhold: {e.get('description', '')} "
            f"| regler for utlevering: {e.get('rules', 'Ingen spesielle krav utover de generelle reglene.')}"
        )
    prompt = PROMPT_FILE.read_text(encoding="utf-8")
    prompt = prompt.replace("{{KATALOG}}", "\n".join(lines))
    prompt = prompt.replace("{{ANALYTIKER}}", analyst)
    prompt = prompt.replace("{{DATO}}", datetime.date.today().isoformat())
    return prompt


def safe_path(filename: str) -> Path | None:
    p = (LOG_DIR / filename).resolve()
    if p.parent != LOG_DIR or not p.is_file() or p.name == "catalog.json":
        return None
    return p


class ChatRequest(BaseModel):
    analyst: str
    messages: list[dict]


@app.post("/api/chat")
async def chat(req: ChatRequest, request: Request):
    analyst = (req.analyst or "").strip()[:60] or "ukjent"
    ip = request.client.host if request.client else "?"
    catalog = load_catalog()
    files = {e["file"]: e for e in catalog}

    # Bare bruker/assistent-meldinger fra nettleseren slippes inn (ingen falske systemmeldinger).
    history = [
        {"role": m["role"], "content": str(m.get("content", ""))[:4000]}
        for m in req.messages[-20:]
        if m.get("role") in ("user", "assistant")
    ]
    if not history or history[-1]["role"] != "user":
        raise HTTPException(400, "Siste melding må være fra brukeren.")

    audit({"type": "melding", "analytiker": analyst, "ip": ip, "tekst": history[-1]["content"]})

    msgs = [{"role": "system", "content": build_system_prompt(catalog, analyst)}] + history
    released = []
    msg: dict = {}

    async with httpx.AsyncClient(timeout=600) as client:
        for _ in range(MAX_TOOL_ROUNDS + 1):
            try:
                r = await client.post(
                    f"{OLLAMA_URL}/api/chat",
                    json={
                        "model": MODEL,
                        "messages": msgs,
                        "tools": TOOLS,
                        "stream": False,
                        "options": {"temperature": 0.4},
                    },
                )
            except httpx.HTTPError as e:
                raise HTTPException(502, f"Får ikke kontakt med språkmodellen: {e}")
            if r.status_code != 200:
                raise HTTPException(502, f"Språkmodellen svarte med feil: {r.text[:300]}")

            msg = r.json().get("message", {})
            calls = msg.get("tool_calls") or []
            if not calls:
                break

            msgs.append(msg)
            for call in calls:
                fn = call.get("function", {})
                args = fn.get("arguments") or {}
                if isinstance(args, str):
                    try:
                        args = json.loads(args)
                    except json.JSONDecodeError:
                        args = {}

                if fn.get("name") != "gi_ut_logg":
                    result = "Feil: ukjent verktøy."
                else:
                    fil = str(args.get("fil", "")).strip()
                    path = safe_path(fil) if fil in files else None
                    if not path:
                        result = f"Feil: filen '{fil}' finnes ikke i katalogen. Ingenting ble gitt ut."
                    elif any(x["file"] == fil for x in released):
                        result = f"{fil} er allerede gitt ut i dette svaret."
                    else:
                        token = secrets.token_urlsafe(16)
                        downloads[token] = fil
                        released.append({"file": fil, "host": files[fil].get("host", ""), "url": f"/download/{token}"})
                        audit({"type": "utlevert", "analytiker": analyst, "ip": ip, "fil": fil,
                               "begrunnelse": args.get("begrunnelse", "")})
                        result = (
                            f"OK: {fil} er gitt ut til {analyst}. Brukeren får nedlastingslenken automatisk. "
                            "Ikke skriv lenke eller innhold selv, bare bekreft kort."
                        )
                msgs.append({"role": "tool", "content": result, "tool_name": fn.get("name", "")})

    reply = (msg.get("content") or "").strip()
    if not reply:
        reply = "Anmodningen er behandlet." if released else "Jeg har ikke noe svar på det. Kan du omformulere anmodningen?"

    audit({"type": "svar", "analytiker": analyst, "ip": ip, "tekst": reply,
           "utlevert": [x["file"] for x in released]})
    return {"reply": reply, "released": released}


@app.get("/download/{token}")
async def download(token: str):
    fil = downloads.get(token)
    path = safe_path(fil) if fil else None
    if not path:
        raise HTTPException(404, "Ukjent eller utløpt lenke.")
    return FileResponse(path, filename=path.name)


@app.get("/api/status")
async def status():
    try:
        async with httpx.AsyncClient(timeout=3) as client:
            r = await client.get(f"{OLLAMA_URL}/api/tags")
            models = [m["name"] for m in r.json().get("models", [])]
        ok = any(m == MODEL or m.startswith(MODEL + ":") for m in models)
        return {"online": ok, "model": MODEL}
    except Exception:
        return {"online": False, "model": MODEL}


app.mount("/", StaticFiles(directory=BASE / "static", html=True), name="static")
