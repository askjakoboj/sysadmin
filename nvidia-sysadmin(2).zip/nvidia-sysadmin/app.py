"""
NVIDIA IT - AI-systemadministrator
En liten webapp der SOC-analytikere ber om logger. AI-en vurderer anmodningen,
og hvis den godkjenner, leverer appen den ORIGINALE filen fra logs/-mappen.
AI-en ser aldri innholdet i loggene, bare katalogen (logs/catalog.json).
"""
import asyncio
import datetime
import hashlib
import json
import os
import re
import secrets
import time
from pathlib import Path

import httpx
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

BASE = Path(__file__).resolve().parent
LOG_DIR = BASE / "logs"
CATALOG_FILE = LOG_DIR / "catalog.json"
PROMPT_FILE = BASE / "system_prompt.txt"
AUDIT_FILE = BASE / "audit.jsonl"
ADMIN_FILE = BASE / "admin_password"   # salt$pbkdf2-hash, lages av set_password.sh
SESSION_HOURS = 8
SAFE_NAME = re.compile(r"^[A-Za-z0-9._-]{1,120}$")

OLLAMA_URL = os.getenv("OLLAMA_URL", "http://127.0.0.1:11434")
MODEL = os.getenv("MODEL", "qwen2.5:7b")
MAX_TOOL_ROUNDS = 3

app = FastAPI(title="NVIDIA IT - Systemadministrator")
downloads: dict[str, str] = {}  # token -> filnavn

TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "gi_ut_logg",
            "description": (
                "Gir analytikeren tilgang til en loggfil fra katalogen. "
                "Kall KUN denne når anmodningen er godkjent etter reglene dine."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "fil": {"type": "string", "description": "Eksakt filnavn fra katalogen"},
                    "begrunnelse": {"type": "string", "description": "Kort begrunnelse for at anmodningen godkjennes"},
                },
                "required": ["fil", "begrunnelse"],
            },
        },
    }
]


def now() -> str:
    return datetime.datetime.now().isoformat(timespec="seconds")


def audit(entry: dict) -> None:
    entry = {"tid": now(), **entry}
    with AUDIT_FILE.open("a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")


def load_catalog() -> list[dict]:
    # Leses på nytt ved hver forespørsel, så du kan endre katalogen uten omstart.
    return json.loads(CATALOG_FILE.read_text(encoding="utf-8"))


def build_system_prompt(catalog: list[dict], analyst: str) -> str:
    lines = []
    for e in catalog:
        lines.append(
            f"- fil: {e['file']} | maskin: {e.get('host', '?')} | innhold: {e.get('description', '')} "
            f"| regler for utlevering: {e.get('rules', 'Ingen spesielle krav utover de generelle reglene.')}"
        )
    prompt = PROMPT_FILE.read_text(encoding="utf-8")
    if "{{KATALOG}}" not in prompt:
        # Sikkerhetsnett: AI-en må alltid kjenne katalogen, selv om plassholderen er slettet.
        prompt += "\n\nLOGGKATALOG (dette er ALT du kan gi ut)\n{{KATALOG}}"
    prompt = prompt.replace("{{KATALOG}}", "\n".join(lines))
    prompt = prompt.replace("{{ANALYTIKER}}", analyst)
    prompt = prompt.replace("{{DATO}}", datetime.date.today().isoformat())
    return prompt


def safe_path(filename: str) -> Path | None:
    p = (LOG_DIR / filename).resolve()
    if p.parent != LOG_DIR or not p.is_file() or p.name == "catalog.json":
        return None
    return p


class ChatRequest(BaseModel):
    analyst: str
    messages: list[dict]


@app.post("/api/chat")
async def chat(req: ChatRequest, request: Request):
    analyst = (req.analyst or "").strip()[:60] or "ukjent"
    ip = request.client.host if request.client else "?"
    catalog = load_catalog()
    files = {e["file"]: e for e in catalog}

    # Bare bruker/assistent-meldinger fra nettleseren slippes inn (ingen falske systemmeldinger).
    history = [
        {"role": m["role"], "content": str(m.get("content", ""))[:4000]}
        for m in req.messages[-20:]
        if m.get("role") in ("user", "assistant")
    ]
    if not history or history[-1]["role"] != "user":
        raise HTTPException(400, "Siste melding må være fra brukeren.")

    audit({"type": "melding", "analytiker": analyst, "ip": ip, "tekst": history[-1]["content"]})

    msgs = [{"role": "system", "content": build_system_prompt(catalog, analyst)}] + history
    released = []
    msg: dict = {}

    async with httpx.AsyncClient(timeout=600) as client:
        for _ in range(MAX_TOOL_ROUNDS + 1):
            try:
                r = await client.post(
                    f"{OLLAMA_URL}/api/chat",
                    json={
                        "model": MODEL,
                        "messages": msgs,
                        "tools": TOOLS,
                        "stream": False,
                        "options": {"temperature": 0.4},
                    },
                )
            except httpx.HTTPError as e:
                raise HTTPException(502, f"Får ikke kontakt med språkmodellen: {e}")
            if r.status_code != 200:
                raise HTTPException(502, f"Språkmodellen svarte med feil: {r.text[:300]}")

            msg = r.json().get("message", {})
            calls = msg.get("tool_calls") or []
            if not calls:
                break

            msgs.append(msg)
            for call in calls:
                fn = call.get("function", {})
                args = fn.get("arguments") or {}
                if isinstance(args, str):
                    try:
                        args = json.loads(args)
                    except json.JSONDecodeError:
                        args = {}

                if fn.get("name") != "gi_ut_logg":
                    result = "Feil: ukjent verktøy."
                else:
                    fil = str(args.get("fil", "")).strip()
                    path = safe_path(fil) if fil in files else None
                    if not path:
                        result = f"Feil: filen '{fil}' finnes ikke i katalogen. Ingenting ble gitt ut."
                    elif any(x["file"] == fil for x in released):
                        result = f"{fil} er allerede gitt ut i dette svaret."
                    else:
                        token = secrets.token_urlsafe(16)
                        downloads[token] = fil
                        released.append({"file": fil, "host": files[fil].get("host", ""), "url": f"/download/{token}"})
                        audit({"type": "utlevert", "analytiker": analyst, "ip": ip, "fil": fil,
                               "begrunnelse": args.get("begrunnelse", "")})
                        result = (
                            f"OK: {fil} er gitt ut til {analyst}. Brukeren får nedlastingslenken automatisk. "
                            "Ikke skriv lenke eller innhold selv, bare bekreft kort."
                        )
                msgs.append({"role": "tool", "content": result, "tool_name": fn.get("name", "")})

    reply = (msg.get("content") or "").strip()
    if not reply:
        reply = "Anmodningen er behandlet." if released else "Jeg har ikke noe svar på det. Kan du omformulere anmodningen?"

    audit({"type": "svar", "analytiker": analyst, "ip": ip, "tekst": reply,
           "utlevert": [x["file"] for x in released]})
    return {"reply": reply, "released": released}


@app.get("/download/{token}")
async def download(token: str):
    fil = downloads.get(token)
    path = safe_path(fil) if fil else None
    if not path:
        raise HTTPException(404, "Ukjent eller utløpt lenke.")
    return FileResponse(path, filename=path.name)


@app.get("/api/status")
async def status():
    try:
        async with httpx.AsyncClient(timeout=3) as client:
            r = await client.get(f"{OLLAMA_URL}/api/tags")
            models = [m["name"] for m in r.json().get("models", [])]
        ok = any(m == MODEL or m.startswith(MODEL + ":") for m in models)
        return {"online": ok, "model": MODEL}
    except Exception:
        return {"online": False, "model": MODEL}


# ----------------------------------------------------------------------------
# ADMIN
# ----------------------------------------------------------------------------
sessions: dict[str, float] = {}  # token -> utløpstid


def check_password(pw: str) -> bool:
    try:
        salt, stored = ADMIN_FILE.read_text().strip().split("$")
    except Exception:
        return False
    calc = hashlib.pbkdf2_hmac("sha256", pw.encode(), bytes.fromhex(salt), 200_000).hex()
    return secrets.compare_digest(calc, stored)


def require_admin(request: Request) -> None:
    exp = sessions.get(request.cookies.get("admin_session") or "")
    if not exp or exp < time.time():
        raise HTTPException(401, "Ikke innlogget")


def save_catalog(catalog: list[dict]) -> None:
    tmp = CATALOG_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(catalog, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(CATALOG_FILE)


def valid_name(name: str) -> str:
    if not SAFE_NAME.match(name) or name.startswith(".") or name in ("catalog.json", "catalog.tmp"):
        raise HTTPException(400, "Ugyldig filnavn. Bruk bare bokstaver, tall, punktum, bindestrek og understrek.")
    return name


class LoginRequest(BaseModel):
    password: str


class EntryUpdate(BaseModel):
    host: str = ""
    description: str = ""
    rules: str = ""


class PromptUpdate(BaseModel):
    text: str


@app.get("/admin")
async def admin_page():
    return FileResponse(BASE / "static" / "admin.html")


@app.post("/admin/api/login")
async def admin_login(body: LoginRequest, request: Request):
    ip = request.client.host if request.client else "?"
    if not ADMIN_FILE.exists():
        raise HTTPException(503, "Admin-passord er ikke satt. Kjør: sudo bash set_password.sh")
    if not check_password(body.password):
        audit({"type": "admin_innlogging_feilet", "ip": ip})
        await asyncio.sleep(1)
        raise HTTPException(401, "Feil passord")
    token = secrets.token_urlsafe(32)
    sessions[token] = time.time() + SESSION_HOURS * 3600
    audit({"type": "admin_innlogget", "ip": ip})
    resp = JSONResponse({"ok": True})
    resp.set_cookie("admin_session", token, httponly=True, samesite="strict", max_age=SESSION_HOURS * 3600)
    return resp


@app.post("/admin/api/logout")
async def admin_logout(request: Request):
    sessions.pop(request.cookies.get("admin_session") or "", None)
    resp = JSONResponse({"ok": True})
    resp.delete_cookie("admin_session")
    return resp


@app.get("/admin/api/files")
async def admin_files(request: Request):
    require_admin(request)
    counts: dict[str, int] = {}
    if AUDIT_FILE.exists():
        for line in AUDIT_FILE.read_text(encoding="utf-8").splitlines():
            try:
                e = json.loads(line)
            except json.JSONDecodeError:
                continue
            if e.get("type") == "utlevert":
                counts[e.get("fil", "")] = counts.get(e.get("fil", ""), 0) + 1
    catalog = load_catalog()
    listed = {e["file"] for e in catalog}
    out = []
    for e in catalog:
        p = LOG_DIR / e["file"]
        out.append({**e, "exists": p.is_file(), "size": p.stat().st_size if p.is_file() else 0,
                    "released": counts.get(e["file"], 0)})
    unlisted = sorted(p.name for p in LOG_DIR.iterdir()
                      if p.is_file() and p.name not in listed and p.name not in ("catalog.json", "catalog.tmp"))
    return {"files": out, "unlisted": unlisted}


@app.put("/admin/api/files/{name}")
async def admin_upload(name: str, request: Request, host: str = "", description: str = "", rules: str = ""):
    """Laster opp (eller erstatter) en fil. Innholdet sendes som rå body."""
    require_admin(request)
    name = valid_name(name)
    tmp = LOG_DIR / f".upload-{secrets.token_hex(6)}"
    size = 0
    with tmp.open("wb") as f:
        async for chunk in request.stream():
            size += len(chunk)
            f.write(chunk)
    tmp.replace(LOG_DIR / name)

    catalog = load_catalog()
    entry = next((e for e in catalog if e["file"] == name), None)
    if entry is None:
        catalog.append({"file": name, "host": host, "description": description, "rules": rules})
    elif host or description or rules:
        entry.update({"host": host, "description": description, "rules": rules})
    save_catalog(catalog)
    audit({"type": "admin_lastet_opp", "fil": name, "bytes": size})
    return {"ok": True, "size": size}


@app.put("/admin/api/catalog/{name}")
async def admin_update_entry(name: str, body: EntryUpdate, request: Request):
    require_admin(request)
    name = valid_name(name)
    catalog = load_catalog()
    entry = next((e for e in catalog if e["file"] == name), None)
    if entry is None:
        if not (LOG_DIR / name).is_file():
            raise HTTPException(404, "Filen finnes ikke")
        entry = {"file": name}
        catalog.append(entry)
    entry.update(body.model_dump())
    save_catalog(catalog)
    audit({"type": "admin_endret_katalog", "fil": name})
    return {"ok": True}


@app.delete("/admin/api/files/{name}")
async def admin_delete(name: str, request: Request):
    require_admin(request)
    name = valid_name(name)
    catalog = [e for e in load_catalog() if e["file"] != name]
    save_catalog(catalog)
    (LOG_DIR / name).unlink(missing_ok=True)
    for t in [t for t, f in downloads.items() if f == name]:
        downloads.pop(t, None)
    audit({"type": "admin_slettet", "fil": name})
    return {"ok": True}


@app.get("/admin/api/prompt")
async def admin_get_prompt(request: Request):
    require_admin(request)
    return {"text": PROMPT_FILE.read_text(encoding="utf-8")}


@app.put("/admin/api/prompt")
async def admin_set_prompt(body: PromptUpdate, request: Request):
    require_admin(request)
    if not body.text.strip():
        raise HTTPException(400, "Instruksene kan ikke være tomme.")
    backup = PROMPT_FILE.with_suffix(".bak")
    backup.write_text(PROMPT_FILE.read_text(encoding="utf-8"), encoding="utf-8")
    PROMPT_FILE.write_text(body.text, encoding="utf-8")
    audit({"type": "admin_endret_instrukser"})
    return {"ok": True}


@app.get("/admin/api/audit")
async def admin_audit(request: Request, limit: int = 300):
    require_admin(request)
    if not AUDIT_FILE.exists():
        return {"entries": []}
    lines = AUDIT_FILE.read_text(encoding="utf-8").splitlines()[-limit:]
    entries = []
    for line in reversed(lines):
        try:
            entries.append(json.loads(line))
        except json.JSONDecodeError:
            pass
    return {"entries": entries}


app.mount("/", StaticFiles(directory=BASE / "static", html=True), name="static")
